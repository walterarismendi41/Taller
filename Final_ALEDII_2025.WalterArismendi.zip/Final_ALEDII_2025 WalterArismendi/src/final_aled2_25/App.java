/**
 *
 * @author Walter
 */
package final_aled2_25;
import final_aled2_25.view.LoginView;


public class App {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> new LoginView().setVisible(true));
    }
    
}
