/**
 *
 * @author Walter
 */
package final_aled2_25.model.dao;

import java.util.List;
import final_aled2_25.model.entity.Repuesto;

public interface RepuestoDAO {
    java.util.List<Repuesto> findAll();
    Repuesto findById(int id);
}
