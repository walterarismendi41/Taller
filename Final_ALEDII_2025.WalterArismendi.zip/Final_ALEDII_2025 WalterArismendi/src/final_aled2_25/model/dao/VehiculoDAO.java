/**
 *
 * @author Walter
 */
package final_aled2_25.model.dao;

import final_aled2_25.model.entity.Vehiculo;

public interface VehiculoDAO {
    
    void insert (Vehiculo v);
    void update (Vehiculo v);
    void delete (String dominio);
    java.util.List<Vehiculo> findAll();
    boolean exists(String dominio);
   
}
