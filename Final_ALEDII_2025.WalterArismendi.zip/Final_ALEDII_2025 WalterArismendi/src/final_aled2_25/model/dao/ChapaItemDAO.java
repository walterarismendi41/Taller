/**
 *
 * @author Walter
 */
package final_aled2_25.model.dao;

import java.util.List;

public interface ChapaItemDAO {
    void insert (String dominio, String descripcion, java.math.BigDecimal horas, java.math.BigDecimal precioHora, java.math.BigDecimal subtotal);
    void delete(int id);
    java.util.List<Object[]> findByVehiculo(String dominio); //[id, descripcion, horas, precioHora, subtotal]

}
