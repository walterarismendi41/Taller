/**
 *
 * @author Walter
 */
package final_aled2_25.view;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import final_aled2_25.model.dao.*;
import final_aled2_25.model.entity.Repuesto;


public class MecanicaView extends javax.swing.JFrame {
    
    //GLOBALES
    private final VehiculoDAO vehiculoDAO = new JdbcVehiculoDAO();
    private final RepuestoDAO repuestoDAO = new JdbcRepuestoDAO();
    private final MecanicaItemDAO mecDAO = new JdbcMecanicaItemDAO();
    
    private DefaultTableModel modelMec;
    private boolean cargando =false; //para silenciar eventos al llenar combos

    public MecanicaView() {
        initComponents();
        setTitle("Mecanica");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); // cierra solo la ventana 
        
        configurarTabla();
        inicializarCombos();
        actualizarPrecioPorRepuesto();
        cargarTabla();
    }

    
    //MIS METODOS

    private void configurarTabla() {
        modelMec = new DefaultTableModel(new Object[][]{}, new String[]{
            "ID","Repuesto","Precio","Cant.","Subtotal"
        }) { @Override public boolean isCellEditable(int r,int c){return false;} };
        tblMecanica.setModel(modelMec);
        tblMecanica.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void inicializarCombos() {
        cargando = true; // <<< evita que los handlers actúen mientras llenás
        try {
            // Vehículos
            cboVehiculo.removeAllItems();
            vehiculoDAO.findAll().forEach(v -> cboVehiculo.addItem(v.getDominio()));

            // Repuestos (objetos Repuesto)
            DefaultComboBoxModel<Repuesto> repModel = new DefaultComboBoxModel<>();
            for (Repuesto r : repuestoDAO.findAll()) repModel.addElement(r);
            cboRepuesto.setModel(repModel);
        } finally {
            cargando = false;
        }
    }

    private void cargarTabla() {
        
        if (modelMec == null) return; 
        
        modelMec.setRowCount(0);
        String dom = (String) cboVehiculo.getSelectedItem();
        if (dom == null || dom.isEmpty()) return;
        List<Object[]> filas = mecDAO.findByVehiculo(dom);
        for (Object[] f : filas) modelMec.addRow(f);
    }

    private void actualizarPrecioPorRepuesto() {
        Repuesto r = (Repuesto) cboRepuesto.getSelectedItem();
        if (r != null) {
            txtPrecioUnit.setText(r.getPrecio().setScale(2, RoundingMode.HALF_UP).toString());
        } else {
            txtPrecioUnit.setText("");
        }
    }

    private BigDecimal parse2(String s, String campo) throws Exception {
        if (s == null || s.trim().isEmpty()) throw new Exception(campo + " requerido.");
        try {
            return new BigDecimal(s.replace(",", ".")).setScale(2, RoundingMode.HALF_UP);
        } catch (NumberFormatException ex) {
            throw new Exception(campo + " inválido.");
        }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtPrecioUnit = new javax.swing.JTextField();
        txtCantidad = new javax.swing.JTextField();
        cboVehiculo = new javax.swing.JComboBox<>();
        cboRepuesto = new javax.swing.JComboBox<>();
        btnAgregar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMecanica = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setText("MECANICA");

        txtPrecioUnit.setEditable(false);

        cboVehiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboVehiculoActionPerformed(evt);
            }
        });

        cboRepuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboRepuestoActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAgregar.setText("AGREGAR");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        tblMecanica.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblMecanica);

        jLabel2.setText("Vehiculo:");

        jLabel3.setText("Repuesto:");

        jLabel4.setText("Precio Unitario:");

        jLabel5.setText("Cantidad:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnAgregar)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(4, 4, 4)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtPrecioUnit, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                    .addComponent(txtCantidad))))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEliminar)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(cboRepuesto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cboVehiculo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(184, 184, 184)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPrecioUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2)
                    .addComponent(cboVehiculo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(cboRepuesto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnEliminar)
                    .addComponent(btnAgregar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboVehiculoActionPerformed

        if (cargando) return; //evitamos con este GUARD cargar mientras se llenan  los combos
        cargarTabla();
    }//GEN-LAST:event_cboVehiculoActionPerformed

    private void cboRepuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboRepuestoActionPerformed

        if (cargando) return; //evitamos con este GUARD cargar mientras se llenan  los combos
        actualizarPrecioPorRepuesto();
    }//GEN-LAST:event_cboRepuestoActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed

        try {
            String dom = (String) cboVehiculo.getSelectedItem();
            if (dom == null || dom.isEmpty()) throw new Exception("Seleccione un vehículo.");
            
            Repuesto r = (Repuesto) cboRepuesto.getSelectedItem();
            if (r == null) throw new Exception("Seleccione un repuesto.");
            
            BigDecimal precio = parse2(txtPrecioUnit.getText(), "Precio");
            BigDecimal cant   = parse2(txtCantidad.getText(), "Cantidad");
            BigDecimal subtotal = precio.multiply(cant).setScale(2, RoundingMode.HALF_UP);

            mecDAO.insert(dom, r.getId(), cant, precio, subtotal);
            
            cargarTabla();
            
            txtCantidad.setText("");
            txtCantidad.requestFocus();
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed

        int row = tblMecanica.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Seleccione una fila."); return; }
        int id = Integer.parseInt(modelMec.getValueAt(row, 0).toString());
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar ítem?", "Confirmar",
                JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
            try { 
                mecDAO.delete(id);
                cargarTabla(); 
            }
            catch (Exception ex) { 
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MecanicaView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<final_aled2_25.model.entity.Repuesto> cboRepuesto;
    private javax.swing.JComboBox<String> cboVehiculo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblMecanica;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtPrecioUnit;
    // End of variables declaration//GEN-END:variables
}
