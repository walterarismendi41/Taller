/**
 *
 * @author Walter
 */
package final_aled2_25.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import final_aled2_25.model.dao.*;

public class ChapaView extends javax.swing.JFrame {
    
    //GLOBALES
    private final VehiculoDAO vehiculoDAO = new JdbcVehiculoDAO();
    private final ChapaItemDAO chapaDAO = new JdbcChapaItemDAO();
    
    private DefaultTableModel modelChapa;
    private boolean cargando = false; //flag para silenciar eventos al llenar combos

    
    public ChapaView() {
        initComponents();
        setTitle("Chapa y Pintura");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); // cierra solo la ventana 
        
        
        configurarTabla();
        inicializarCombos();
        cargarTabla();
    }
    
    //MIS METODOS
    // ===== INICIALIZACIONES =====
    private void configurarTabla() {
        modelChapa = new DefaultTableModel(new Object[][]{}, new String[]{
            "ID","Descripción","Horas","Precio/h","Subtotal"
        }) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tblChapa.setModel(modelChapa);
        tblChapa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void inicializarCombos() {
        cargando = true; // evita que se disparen handlers mientras llenamos
        try {
            cboVehiculo.removeAllItems();
            for (final_aled2_25.model.entity.Vehiculo v : vehiculoDAO.findAll()) {
                cboVehiculo.addItem(v.getDominio());
            }
            // si querés seleccionar el primero explícitamente:
            if (cboVehiculo.getItemCount() > 0 && cboVehiculo.getSelectedIndex() < 0) {
                cboVehiculo.setSelectedIndex(0);
            }
        } finally {
            cargando = false;
        }
    }

    // ===== LÓGICA =====
    private void cargarTabla() {
        if (modelChapa == null) return; // safety
        modelChapa.setRowCount(0);
        String dom = (String) cboVehiculo.getSelectedItem();
        if (dom == null || dom.isEmpty()) return;
        List<Object[]> filas = chapaDAO.findByVehiculo(dom);
        for (Object[] f : filas) modelChapa.addRow(f);
    }

    private BigDecimal parse2(String s, String campo) throws Exception {
        if (s == null || s.trim().isEmpty()) throw new Exception(campo + " requerido.");
        try { return new BigDecimal(s.replace(",", ".")).setScale(2, RoundingMode.HALF_UP); }
        catch (NumberFormatException ex) { throw new Exception(campo + " inválido."); }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cboVehiculo = new javax.swing.JComboBox<>();
        txtDescripcion = new javax.swing.JTextField();
        txtHoras = new javax.swing.JTextField();
        txtPrecioHora = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblChapa = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        cboVehiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboVehiculoActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAgregar.setText("AGREGAR");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        tblChapa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblChapa);

        jLabel1.setText("Precio Hora:");

        jLabel2.setText("Horas:");

        jLabel3.setText("Descripción:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel4.setText("CHAPA Y PINTURA");

        jLabel5.setText("Vehiculo:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDescripcion)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtHoras, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                    .addComponent(txtPrecioHora))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cboVehiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                    .addComponent(btnEliminar)
                                    .addComponent(btnAgregar))
                                .addGap(1, 1, 1))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(151, 151, 151)
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtHoras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cboVehiculo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5)
                        .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPrecioHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboVehiculoActionPerformed

        if (cargando) return; //GUARD para llenar combos mientras...
        cargarTabla();
    }//GEN-LAST:event_cboVehiculoActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed

        try {
            String dom = (String) cboVehiculo.getSelectedItem();
            if (dom == null || dom.isEmpty()) throw new Exception("Seleccione un vehículo.");
            String desc = txtDescripcion.getText().trim();
            if (desc.isEmpty()) throw new Exception("Descripción requerida.");
            BigDecimal horas  = parse2(txtHoras.getText(), "Horas");
            BigDecimal precio = parse2(txtPrecioHora.getText(), "Precio/h");
            BigDecimal subtotal = horas.multiply(precio).setScale(2, RoundingMode.HALF_UP);

            chapaDAO.insert(dom, desc, horas, precio, subtotal);
            cargarTabla();
            txtDescripcion.setText(""); txtHoras.setText(""); txtPrecioHora.setText("");
            txtDescripcion.requestFocus();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed

        int row = tblChapa.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Seleccione una fila."); return; }
        int id = Integer.parseInt(modelChapa.getValueAt(row, 0).toString());
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar ítem?", "Confirmar",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                chapaDAO.delete(id);
                cargarTabla();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
    }//GEN-LAST:event_btnEliminarActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ChapaView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<String> cboVehiculo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblChapa;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtHoras;
    private javax.swing.JTextField txtPrecioHora;
    // End of variables declaration//GEN-END:variables
}
