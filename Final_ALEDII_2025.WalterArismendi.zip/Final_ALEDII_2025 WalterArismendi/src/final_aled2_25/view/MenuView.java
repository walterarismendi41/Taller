/**
 *
 * @author Walter
 */
package final_aled2_25.view;

import final_aled2_25.model.entity.Usuario;
import javax.swing.*;

public class MenuView extends javax.swing.JFrame {

    private Usuario usuario; // <-- lo guardamos para saber el rol al abrir vistas
    
    public MenuView() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); //Cierro el programa al cerrar ventana
        setLocationRelativeTo(null);
        pack();
    }
        
    public MenuView(Usuario u){
        this(); //llama al constructor sin parametro (defecto)
        this.usuario = u; //guardamos el usuario con rol
        aplicarPermisos(u);
    }
    
    private void aplicarPermisos(Usuario u) {
        // Evitá NPE si el rol es null
        String rol = (u.getRol() == null) ? "" : u.getRol().toUpperCase();
 
        boolean isAdmin = "ADMIN".equals(rol);
        boolean isChap  = "CHAPISTA".equals(rol);
        boolean isMec   = "MECANICO".equals(rol);
 
        setTitle("Menú — Usuario: " + u.getUsername() + " — Rol: " + rol);
 
        btnVehiculos.setEnabled(isAdmin);
        btnChapa.setEnabled(isAdmin || isChap);
        btnMecanica.setEnabled(isAdmin || isMec);
        btnPresupuestos.setEnabled(isAdmin);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnVehiculos = new javax.swing.JButton();
        btnMecanica = new javax.swing.JButton();
        btnChapa = new javax.swing.JButton();
        btnPresupuestos = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnVehiculos.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btnVehiculos.setText("VEHICULOS");
        btnVehiculos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnVehiculos.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnVehiculos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVehiculosActionPerformed(evt);
            }
        });

        btnMecanica.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btnMecanica.setText("MECANICA");
        btnMecanica.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnMecanica.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnMecanica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMecanicaActionPerformed(evt);
            }
        });

        btnChapa.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btnChapa.setText("CHAPA Y PINTURA");
        btnChapa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnChapa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnChapa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChapaActionPerformed(evt);
            }
        });

        btnPresupuestos.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btnPresupuestos.setText("PRESUPUESTOS");
        btnPresupuestos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnPresupuestos.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnPresupuestos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPresupuestosActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setText("MENU PRINCIPAL");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 0));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText(" - - - - - - - - - - - - - - - - - - ");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 102, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText(" - - - - - - - - - - - - - - - - - - ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel4)
                    .addComponent(jLabel1)
                    .addComponent(btnVehiculos, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMecanica, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChapa, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPresupuestos, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addComponent(btnVehiculos, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnMecanica, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnChapa, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnPresupuestos, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVehiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVehiculosActionPerformed

        VehiculosView vehiculo = new VehiculosView();
        vehiculo.setVisible(true);
        
    }//GEN-LAST:event_btnVehiculosActionPerformed

    private void btnMecanicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMecanicaActionPerformed

        MecanicaView mecanica = new MecanicaView();
        mecanica.setVisible(true);
    }//GEN-LAST:event_btnMecanicaActionPerformed

    private void btnChapaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChapaActionPerformed

        ChapaView chapa = new ChapaView();
        chapa.setVisible(true);
    }//GEN-LAST:event_btnChapaActionPerformed

    private void btnPresupuestosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPresupuestosActionPerformed

        PresupuestosView presupuestos = new PresupuestosView();
        presupuestos.setVisible(true);
    }//GEN-LAST:event_btnPresupuestosActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChapa;
    private javax.swing.JButton btnMecanica;
    private javax.swing.JButton btnPresupuestos;
    private javax.swing.JButton btnVehiculos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
