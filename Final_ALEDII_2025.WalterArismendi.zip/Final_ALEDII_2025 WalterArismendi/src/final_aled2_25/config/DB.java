/**
 *
 * @author Walter
 */
package final_aled2_25.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/taller?useSSL=false&serverTimezone=UTC";
        String user = "root";   // usuario MySQL
        String pass = "";       // contraseña MySQL
        return DriverManager.getConnection(url, user, pass);
    }
}